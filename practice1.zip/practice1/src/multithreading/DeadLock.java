package multithreading;

public class DeadLock {

	public static void main(String[] args) {
		final String resource1 = "ratan ";
		final String resource2 = "jaiswal";
		Thread t1 = new Thread() {
			public void run() {
				synchronized (resource1) {
					synchronized (resource2) {
						System.out.println("hey ram");
					}
				}
			}
		};
		Thread t2 = new Thread() {
			public void run() {
				synchronized (resource2) {
					synchronized (resource2) {
						System.out.println("hare krishna");
					}
				}
			}
		};
		t1.start();
		t2.start();
	}
}