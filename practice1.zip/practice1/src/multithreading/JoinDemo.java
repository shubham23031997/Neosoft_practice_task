package multithreading;

// If a Thread wants to wait until completing some other Thread then we should go for join() method.
// Every join() method throws InterruptedException, which is checked exception hence 
// compulsory we should handle either by try catch or by throws keyword. 

class MyThread5 implements Runnable {
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println("run Thread");
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				System.out.println("exception occurs");
			}
		}
	}
}

public class JoinDemo {
	public static void main(String[] args) throws Exception, InterruptedException {
		MyThread5 t = new MyThread5();
		Thread t1 = new Thread(t);
		t1.start();
		t1.interrupt();
		t1.join();
		t1.wait();// here we are waiting for t1 for completing their work
//      The wait() is used in with notify() and notifyAll() methods
		for (int i = 0; i < 5; i++) {
			System.out.println("Rama Thread");
		}
	}
}
