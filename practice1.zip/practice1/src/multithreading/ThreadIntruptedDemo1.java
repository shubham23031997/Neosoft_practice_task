package multithreading;

class MyThread7 extends Thread {
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println("iamlazy thread");
		}
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			System.out.println("i got interrupted");
		}
	}
}

public class ThreadIntruptedDemo1 {

	public static void main(String[] args) {
		MyThread7 t = new MyThread7();
		t.start();
		t.interrupt();
		System.out.println("end of main thread");
	}
}
