package multithreading;

class MyThread extends Thread { // ....implements Runnable..... interface is highly
								// recommended....java.lang.package
	/*
	 * if we extends Thread class then there is no chance of extending any other
	 * class hence we are missing the benefits of inheritance. But implementing
	 * Runnable interface we can extend some other class also. & Thread class
	 * internally implements Runnable interface
	 */
	public void run() {
		System.out.println("no arg method");
	}

	public void run(int i) {
		System.out.println("int arg method");
	}

	public void start() {
		super.start();
		System.out.println("start method ");
	}
//	public void start() {
//		System.out.println("start method ");
//	}

// if we override start method then it acts as normal method and run method not get called after calling start method
// if we overload start method and after that we call super.start() then thread will be start and without argument run method called 
}

/*
 * We can overload run() method but Thread class start() method always invokes
 * no argument run() method other overload run() methods we have to call
 * explicitly then only it will be executed just like normal method.
 * 
 */
public class ThreadDemo2 {

	public static void main(String[] args) {
		MyThread t = new MyThread();
//		t.run();
		t.start();
//		t.start();
// if start thread again then illegalThreadException occurs
		System.out.println("main method");
	}
}
