package multithreading;

class ThreadDemo1 extends Thread {
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("child thread running");
		} // execution of child thread
	}
}

public class MyThread1 extends ThreadDemo1 {

	public static void main(String[] args) {

		ThreadDemo1 t = new ThreadDemo1();// instantiation of Thread
//		t.start();// starting of a Thread 
//		t.start() a new Thread created which is responsible for execution of run() method.
		t.run();
//		in case of t.run() no new Thread will created & run() method will be executed just like normal method by main Thread.
		for (int i = 0; i < 10; i++) {
			System.out.println("Parent thread running");
		} // execution of main thread
	}
}
/*
 * If we are not overriding run() method then Thread class run() method will be
 * executed which has empty implementation and hence we won’t get any output.
 * class MyThread extends Thread {} class ThreadDemo { public static void
 * main(String[] args) { MyThread t=new MyThread(); t.start(); } } • It is
 * highly recommended to override run() method. Otherwise don’t go for
 * multithreading concept.
 */
