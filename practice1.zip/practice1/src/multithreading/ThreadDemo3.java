package multithreading;

class MyThread2 extends Thread {
}

public class ThreadDemo3 {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getPriority());// default priority only for main Thread is 5
		Thread.currentThread().setPriority(9);
		System.out.println(Thread.currentThread().getPriority());
		System.out.println(Thread.currentThread().getName());// main
		MyThread2 t = new MyThread2();
		// t.setPriority(10); here we can set priority to thread
		System.out.println(t.getName());// Thread-0
		Thread.currentThread().setName("Shubham Thread");
		t.start();
		System.out.println(Thread.currentThread().getName());// Shubham Thread
	}
}
/*
 * valid range of Thread priorities is 1 to 10[but not 0 to 10 otherwise we will
 * get runtime exception saying “IllegalArgumentException”.] where 1 is least
 * priority and 10 is highest priority. We can get & set priority of a Thread by
 * using following methods.1) public final int getPriority() 2)public final void
 * setPriority(int newPriority);// allowed values are 1 to 10 • default priority
 * only for the main Thread is 5. remaining Threads default priority will be
 * inheriting from parent to child means same priority .
 */