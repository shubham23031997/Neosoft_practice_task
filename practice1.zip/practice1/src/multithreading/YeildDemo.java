package multithreading;

// here Thread class provided by java.lang.package which is always imported by JVM
class MyThread4 implements Runnable {
// if we implements runnable interface then we have only run method 
// here we have to create Thread class object & pass reference of parent class
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			Thread.yield();
// yield() causes to pause current executing Thread for giving chance of remaining waiting Threads of same priority
			System.out.println("run method");
		}
	}
}

public class YeildDemo {

	public static void main(String[] args) {
		MyThread4 t = new MyThread4();
		Thread thread = new Thread(t);
		thread.start();
		for (int i = 0; i < 10; i++) {
			System.out.println("main method");
		}
	}
}