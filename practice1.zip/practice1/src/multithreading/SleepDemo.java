package multithreading;

//If a Thread don’t want to perform any operation for a particular amount of time then we 
//should go for sleep() method. 
class MyThread6 extends Thread {
	public void run() {
		try {
			for (int i = 0; i < 5; i++) {
				System.out.println("i am eagar Thread :" + i);
				Thread.sleep(2000);
			}
		} catch (InterruptedException e) {
			System.out.println("i got interrupted");
		}
	}
}

public class SleepDemo {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("M");
		Thread.sleep(2000);
		System.out.println("E");
		Thread.sleep(2000);
		System.out.println("G");
		Thread.sleep(2000);
		System.out.println("A");
		MyThread6 t = new MyThread6();
		t.start();
		// t.interrupt();
		System.out.println("end of main thread");

	}
}
/*
 * if we uncomment line 1 then main Thread interrupts child Thread & hence child
 * Thread won’t continued until its completion. We can interrupt a sleeping or
 * waiting Thread by using interrupt()(break off) method of Thread class.
 */