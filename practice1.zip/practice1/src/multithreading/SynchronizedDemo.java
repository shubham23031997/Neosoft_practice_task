package multithreading;

class Table {
	synchronized void printTable(int n) {
		// synchronized (this) {// synchronized block
		for (int i = 1; i <= 10; i++) {
			System.out.println(n * i);
		}
	}
}// end of the method
//}

class MyThread8 extends Thread {
	Table t;

	MyThread8(Table t) {
		this.t = t;
	}

	public void run() {
		t.printTable(5);
	}
}

class MyThread9 extends Thread {
	Table t;

	MyThread9(Table t) {
		this.t = t;
	}

	public void run() {
		t.printTable(100);
	}
}

class SynchronizedDemo {
	public static void main(String[] args) {
		Table d1 = new Table();
		MyThread8 t1 = new MyThread8(d1);
		MyThread9 t2 = new MyThread9(d1);
		t1.start();
		t2.start();
	}
}
