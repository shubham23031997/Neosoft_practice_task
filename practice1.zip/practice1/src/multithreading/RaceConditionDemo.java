package multithreading;

class Counter implements Runnable {
	private int c = 0;

	public void increment() {
		c++;
	}

	public void decrement() {
		c--;
	}

	public int getValue() {
		return c;
	}

	@Override
	public void run() {

		this.increment();
		System.out.println("increments " + Thread.currentThread().getName() + " " + this.getValue());

		this.decrement();
		System.out.println("decrement " + Thread.currentThread().getName() + " " + this.getValue());
	}
}

public class RaceConditionDemo {
	public static void main(String args[]) {
		Counter counter = new Counter();
		Thread t1 = new Thread(counter, "Thread-1");
		Thread t2 = new Thread(counter, "Thread-2");
		Thread t3 = new Thread(counter, "Thread-3");
		t1.start();
		t2.start();
		t3.start();
	}
}
