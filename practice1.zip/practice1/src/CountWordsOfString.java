import java.util.HashMap;
import java.util.Map;

public class CountWordsOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Alice Is girl and Bob is boy";
		str = str.toLowerCase();

		Map<String, Integer> hashMap = new HashMap<>();

		String[] words = str.split(" ");

		for (String word : words) {
			if (hashMap.containsKey(word))
				hashMap.put(word, hashMap.get(word) + 1);
			else
				hashMap.put(word, 1);
		}
		System.out.println(hashMap);

	}
}
