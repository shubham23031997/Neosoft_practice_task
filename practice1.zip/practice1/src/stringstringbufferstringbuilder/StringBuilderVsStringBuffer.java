package stringstringbufferstringbuilder;

//StringBuffer is Synchronised and StringBuilder is non-synchronised so that StringBuilder is faster than StringBuffer
public class StringBuilderVsStringBuffer {
	public static void main(String args[]) {
		long startTime = System.currentTimeMillis();

		StringBuffer strBuffer = new StringBuffer("Abc");
		for (int i = 0; i < 300000; i++) {
			strBuffer.append("Xyz");
		}
		System.out.println("Time taken by StringBuffer : " + (System.currentTimeMillis() - startTime) + " ms");

		startTime = System.currentTimeMillis();

		StringBuilder strBuilder = new StringBuilder("Mno");
		for (int i = 0; i < 300000; i++) {
			strBuilder.append("Stu");
		}
		System.out.println("Time taken by StringBuilder : " + (System.currentTimeMillis() - startTime) + " ms");
	}
}
//StringBuffer thread safe. It means two threads can't call the methods of StringBuffer simultaneously.
//StringBuilder not thread safe. It means two threads can call the methods of StringBuilder simultaneously.
