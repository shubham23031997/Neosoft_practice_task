
package stringstringbufferstringbuilder;

class StringInfo1 {

	public static void main(String[] args) {

		String s1 = "Shubham";

		StringBuffer sb = new StringBuffer(s1);
		sb.reverse();// here we using reverse method
		System.out.println(sb);

		StringBuilder sb1 = new StringBuilder(s1);
		sb1.reverse();// here we using reverse method
		System.out.println(sb1);

		StringBuffer sbr = new StringBuffer("shubham");
		// Converting StringBuffer and StringBuilder object to String

		String str = sbr.toString();
		System.out.println("StringBuffer object to String : " + str);

		StringBuilder sbdr = new StringBuilder("mali");
		String str1 = sbdr.toString();
		System.out.println("StringBuilder object to String : " + str1);

	}
}
