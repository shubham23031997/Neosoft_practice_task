package stringstringbufferstringbuilder;

public class StringInfo2 {
	// Concatenates to String

	public static String concat(String s1) {
		return s1 + "mali";// here string is immutable
	}

	public static void concat(StringBuilder s2) {
		s2.append("mali");// adding at end of string
		// here string is mutable
	}

	public static void concat(StringBuffer s3) {
		s3.append("mali");// here string is mutable
	}

	public static void main(String[] args) {

		String s1 = "Shubham";

		concat(s1);
		System.out.println("String after concat: " + s1);

		StringBuilder s2 = new StringBuilder("Shubham ");
//		StringBuilder s2 = new StringBuilder(" " + s1);

		concat(s2);
		System.out.println("StringBuilder: " + s2);

		StringBuffer s3 = new StringBuffer("Shubham ");
		concat(s3);

		System.out.println("StringBuffer: " + s3);
	}
}