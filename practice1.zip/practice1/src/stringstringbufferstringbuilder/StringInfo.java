package stringstringbufferstringbuilder;

public class StringInfo {

	public static void main(String[] args) {

		String string = "ShubhamMali";
		String string1 = "PreparingForMock";
		String string2 = "implementingstring";
		String string3 = "9975229745";

		System.out.println(string.length());// 11

		System.out.println(string.charAt(1));// h

		System.out.println(string.substring(7, 11));// Mali

		System.out.println(string.concat("PUC"));// ShubhamMaliPUC

		System.out.println(string.concat(string1));// ShubhamMaliPreparingForMock

		System.out.println(string.indexOf("b"));// 3

		System.out.println(string.indexOf("i", 4)); // 10

		System.out.println(string.lastIndexOf("m")); // 6

		System.out.println(string.equals(string2)); // false

		System.out.println(string.equalsIgnoreCase(string2));// false

		System.out.println(string.compareTo(string2));// -22

		System.out.println(string.compareToIgnoreCase(string2));// 10

		System.out.println(string.toLowerCase());// shubhammali

		System.out.println(string2.toUpperCase());// IMPLEMENTINGSTRING

		System.out.println(string3.replace("2", "0"));// 9975009745

	}
}
