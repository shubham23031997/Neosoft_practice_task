import java.util.HashMap;
import java.util.Map;

public class HashmapWorking {

	public static void main(String[] args) {
//hashmap is associate array data structure Store data in form of key-pair values
		Map<String, Integer> map1 = new HashMap<String, Integer>();

	}

}
