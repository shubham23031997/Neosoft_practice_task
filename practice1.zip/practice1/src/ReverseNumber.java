import java.util.Scanner;

public class ReverseNumber {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
//        int reverse = 0;
//        while (number != 0) {
//
//            int remainder = number % 10;
//            reverse = remainder + reverse * 10;
//            number = number / 10;
//
//        }
        int  sum = 0, rem;
        if (number % 10 != 0) {
            while (number > 0) {
                rem = number % 10;

                sum = sum*10 + rem;
                number = number / 10;
            }
        }
        System.out.println(sum);


//        for(;number != 0; number /= 10) {
//            int digit = number % 10;
//            reversed = reversed * 10 + digit;
//        }
//        System.out.println("The reverse of the given number is: " + reverse);
    }
}



