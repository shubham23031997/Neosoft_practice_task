import java.util.Scanner;

//a number that is equal to the sum of cubes of its digits. For example
//0, 1, 153, 370, 371 and 407 are the Armstrong numbers.
public class Armstrong {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int number = sc.nextInt();

		int originalNumber, rem, result = 0;

		originalNumber = number;

		while (originalNumber != 0) {
			rem = originalNumber % 10; // 153%10= 3^3=27//15%10=5^3=125//1%10=1^3=1
			result += rem * rem * rem; // result=6+125+1
			originalNumber /= 10; // 153/10=15//15/10=1//1/10=0
		}

		if (result == number)
			System.out.println(number + " is an Armstrong number.");
		else
			System.out.println(number + " is not an Armstrong number.");
	}
}
