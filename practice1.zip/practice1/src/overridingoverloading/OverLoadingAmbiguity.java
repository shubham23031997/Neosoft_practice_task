package overridingoverloading;

class Overload {
	static int add(int i, int j) {
		return i + j;

	}

//	static double add(int i, int j) {
//		return i + j;
//
//	}
// this is ambiguity problem in overloading
}

public class OverLoadingAmbiguity extends Overload {

	public static void main(String[] args) {
		System.out.println(Overload.add(10, 10));
	}
}