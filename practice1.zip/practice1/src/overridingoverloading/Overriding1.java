package overridingoverloading;

class Subtraction {

	void subtract(int a, int b) {
		int c = a - b;
		System.out.println("Subtraction of b from a=" + c);
	}

	final void multiply(int a, int b) {
		int m = a * b;
		System.out.println("multiplication of a and b =" + m);
	}
	// we can not override final method in overriding

	static void method1() {
		System.out.println("I am method 1 in superclass");
	}
}

public class Overriding1 extends Subtraction {
	void subtract(int a, int b) {
		// same name ,same arguments, same return type, different implementation
		int c = b - a;
		System.out.println("Subtraction of a from b=" + c);
	}

	public static void method1() {
		System.out.println("I am method 1 in child class");
	}

	public static void main(String[] args) {

		Overriding1 o = new Overriding1();
		o.subtract(15, 10);
		Subtraction o1 = new Subtraction();
		o1.subtract(120, 15);
		o1.multiply(10, 10);

		Subtraction d1 = new Overriding1();
		// here we taking reference of parent class so that it calling parent method
		// for static method only
		Overriding1 s = new Overriding1();
		d1.method1();
		s.method1();
		Overriding1.method1();
		// we can override static method but its called method hiding not overriding
		// static method are called by reference of class
	}
}
