package overridingoverloading;

class Adder {
	static void add(int a, int b) {
		int c = a + b;
		System.out.println("Addition of  a and b=" + c);

	}

	static double add(double a, float b, int c)
	// same class, different fields(data types),may have different return type
	{
		double d = a + b + c;
		System.out.println("Addition of  a and b and c=" + d);
		return d;
	}

}

public class Overloading1 {

	public static void main(String[] args) {
		Adder adder = new Adder();
		adder.add(10, 20);
		adder.add(10.203, 20.1F, 10);

	}

}
//we can overload final and static method but can't override 