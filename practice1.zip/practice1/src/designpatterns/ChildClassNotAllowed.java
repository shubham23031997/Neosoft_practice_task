package designpatterns;

class A {
	private A() {
	}
}

public class ChildClassNotAllowed {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
