package exceptionhandling;

class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

class CustomExceptionExample {
    public static void main(String[] args) {
        try {
            // Simulating a situation where a custom exception might be thrown
            int result = divide(10, 0);

            // If no exception is thrown, print the result
            System.out.println("Result: " + result);
        } catch (CustomException e) {
            // Catching and handling the custom exception
            System.err.println("Custom Exception Caught: " + e.getMessage());
        } catch (ArithmeticException e) {
            // Catching and handling ArithmeticException (if divide method throws it)
            System.err.println("Arithmetic Exception Caught: " + e.getMessage());
        } finally {
            // Code in the finally block will be executed regardless of whether an exception occurs or not
            System.out.println("Finally block executed");
        }
    }

    // Method that might throw a custom exception
    private static int divide(int numerator, int denominator) throws CustomException {
        if (denominator == 0) {
            // Throwing a custom exception if the denominator is zero
            throw new CustomException("Cannot divide by zero");
        }
        return numerator / denominator;
    }
}

