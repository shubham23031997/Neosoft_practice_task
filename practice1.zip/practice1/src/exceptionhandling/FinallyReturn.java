package exceptionhandling;

public class FinallyReturn {
//	public static void main(String[] args) {
//		try {
//			System.out.println("try block executed");
//			return;
//		} catch (ArithmeticException e) {
//			System.out.println("catch block executed");
//		} finally {
//			System.out.println("finally block executed");
//
//		}
//	}
//}

	/*
	 * If return statement present try catch and finally blocks then finally block
	 * return statement will be considered.
	 */

	public static void main(String[] args) {
		System.out.println(methodOne());
	}

	public static int methodOne() {
		try {
//			System.out.println(10 / 0);
			return 777;
		} catch (ArithmeticException e) {
			e.printStackTrace();
			return 888;
		} finally {

			System.out.println("helo");
			return 999;
		}
	}
}