package exceptionhandling;

public class ThrowsDemo1 {

	public static void main(String[] args) {
		throw new ArithmeticException("/ by zero");
		//System.out.println("hello"); this is unreachable statement
	}
}