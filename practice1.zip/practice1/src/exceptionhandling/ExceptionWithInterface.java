package exceptionhandling;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
// IN UNCHECKED EXCEPTION PARENT CHILD DOESN'T MATTER IN OTHRS ECEPT UNCHECKED 
//IF PARENT THROWS UNCHECKED THEN CHILD MUST THROWS UNCHEAKED AND FOR CHECKED IT CAN THROWS CHECKED AND UNCHECKED

interface Abc {
	public void method1() throws ArithmeticException;
}

class Abc1 {
	public void method1() {
	}
}

public class ExceptionWithInterface extends Abc1 {

	public void method1() throws NullPointerException {
	}

	public static void main(String[] args) {
		Abc obj = (Abc) new ExceptionWithInterface();
		obj.method1();
//		System.out.println("heelo");
	}
}

//An overriding method (subclass method) can not throw a broader exception than an overridden method (superclass method).
//we can't write multiple try block but we can write nested try block means try block within try block with catch or finally or both .