package exceptionhandling;

public class Exception2 {
	public static void main(String[] args) {
		try {
			try {
			} catch (Exception r) {
			} finally {
			} // we can write nested try catch finally blocks in try block
		}
//      System.out.println("hello"); 
		catch (Exception e) {
			try {
			} catch (Exception r) {
			} finally {
			} // we can write nested try catch finally blocks in catch block
		}
//		 System.out.println("hello");not allowed
		finally {
			try {
			} catch (Exception r) {
			} finally {
			} // we can write nested try catch finally blocks in finally block
		}
		System.out.println("hello");
	}
}

/*
 * if we write any statement after try and before catch then it won't works
 * Exception in thread "main" java.lang.Error: Unresolved compilation problems:
 * Syntax error, insert "Finally" to complete BlockStatements Syntax error on
 * token "catch", invalid RecordHeaderName
 * 
 * at exceptionhandling.Exception2.main(Exception2.java:6)
 */
//try must have catch or finally or both ...only catch or only try or only finally won't works'
//we can write only catch block multiple time ...try and finally block we can't write multiple times except nested try block
//also we can't change sequence of try  catch finally respectively  also we an write .'