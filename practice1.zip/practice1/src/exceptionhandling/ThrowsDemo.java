package exceptionhandling;
//“throws” keyword required only for checked exceptions and it delicate responsibility of exception handling to caller method. 
public class ThrowsDemo {

	public static void main(String[] args) throws InterruptedException {
		doStuff();
	}

	public static void doStuff() throws InterruptedException {
		doMoreStuff();
	}

	public static void doMoreStuff() throws InterruptedException {
		Thread.sleep(5000);
		System.out.println("domorestuff");
	}
}
/*
 * if we remove at least one throws Interrupted exception then it wont compile
 * “throws” keyword required only checked exceptions. Usage of throws for
 * unchecked exception there is no use class Test3{ public static void
 * main(String[] args)throws Test3 {} } Output: Compile time error
 * -------------------------------------------------------------------------- 
 * class Test3 extends RuntimeException{
 * public static void main(String[] args)throws Test3 {} } Output: Compile and
 * running successfully.
 */