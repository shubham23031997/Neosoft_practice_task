package exceptionhandling;

import java.util.Scanner;
//we can use only single try block with resources als0 if we want to 

public class SingleTryWithResource {
	public static void main(String[] args) {

		try (Scanner scanner = new Scanner(System.in)) {
			System.out.println("shubham");

		}
	}
}
/*import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class MultipleResourcesExample {
    public static void main(String[] args) {
        // Example of using try-with-resources with multiple resources
        try (
            // Resources to be managed in the try-with-resources block
            BufferedReader reader = new BufferedReader(new FileReader("input.txt"));
            FileWriter writer = new FileWriter("output.txt")
        ) {
            // Code that uses the resources
            String line;
            while ((line = reader.readLine()) != null) {
                // Process each line and write to the output file
                writer.write(line);
            }
        } catch (IOException e) {
            // Handle exceptions
            e.printStackTrace();
        }
    }
}
*/