package exceptionhandling;

public class Exception1 {

	public static void main(String[] args) {
		try {
			System.out.println(10 / 0);

			try {
				String s = null;
				System.out.println("try block");
				System.out.println(s.length());

			} catch (Exception e) {

				e.printStackTrace();
			}

		} catch (ArithmeticException e) {
			System.out.println(10 / 0);
		}

		finally {
			String s = null;
			System.out.println("finally block");
			System.out.println(s.length());
		}
	}
}
// Default exception handler can handle only one exception at a time & that is most recently raised exception. 
