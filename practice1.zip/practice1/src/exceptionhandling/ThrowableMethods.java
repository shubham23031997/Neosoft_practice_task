package exceptionhandling;

public class ThrowableMethods {

	public static void main(String[] args) {
		System.out.println("statement1");
		try {
			System.out.println(10 / 0);
			return;
		} catch (ArithmeticException e) {
			e.printStackTrace();
			System.out.println(e.toString());
			System.out.println(e.getMessage());
			System.out.println(10 / 2);
		} catch (RuntimeException e) {//runtime is parent and arithmetic exception is child 
			System.out.println("runtime exception occures");
		}finally{
			System.out.println("statement3");
	
		}
	}
}

