package exceptionhandling;

import java.util.Scanner;

class TooYoungException extends Exception {
	TooYoungException(String s) {
		super(s);
	}
}

class TooOldException extends Exception {
	TooOldException(String s) {
		super(s);
	}
}

public class CostomizedExceptionDemo  {
	public static void main(String[] args) throws TooOldException,TooYoungException{
		Scanner sc = new Scanner(System.in);
		System.out.println("ENTER AGE : ");
		int age = sc.nextInt();
		if (age< 18 ) {
			throw new TooYoungException("please wait some more time.... u will get best match");
		} else if (age> 60 ) {
			throw new TooOldException("u r age already crossed....no chance of getting married");
		}

		else {
			System.out.println("you will get match details soon by e-mail");
		}
	}
}
