package newpack;
import accessmodifiers.*;

public class DefaultCheck  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultCheck a = new DefaultCheck();
		//a.message(); not able to access default method of default class 
	}

}
