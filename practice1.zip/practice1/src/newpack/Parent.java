package newpack;

public class Parent {

	protected void getInfo() {
		System.out.println("method of NewClass of same package");
	}
}