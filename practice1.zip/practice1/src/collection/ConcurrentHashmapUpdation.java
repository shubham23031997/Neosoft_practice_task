package collection;

import java.util.concurrent.*;
import java.util.*;

public class ConcurrentHashmapUpdation extends Thread {
	static ConcurrentHashMap m = new ConcurrentHashMap();

	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
		}
		System.out.println("child thread sorting map");
		m.put(101, "shubham");
	}

	public static void main(String[] args) throws InterruptedException {
		m.put(102, "Mali");
		m.put(103, "patil");
		m.put(104, "sharma");
		m.put(105, "mishra");
		ConcurrentHashmapUpdation t = new ConcurrentHashmapUpdation();
		t.start();
		Set s = m.keySet();
		Iterator itr = s.iterator();
		
		while (itr.hasNext()) {
			Integer i = (Integer) itr.next();
			System.out.println("main Thread iterating map and curent entry is:" + i + "" + m.get(i));
			Thread.sleep(3000);

		}
		System.out.println(m);
	}

}
