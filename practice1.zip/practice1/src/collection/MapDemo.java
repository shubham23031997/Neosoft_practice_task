package collection;

// Consumer is function interface in forEach
//Anonymous class have not named & it is inner class
//A map contains key and value pair
//A Map doesn't allow duplicate keys, but you can have duplicate values
//HashMap and LinkedHashMap allow null keys and values
//TreeMap doesn't allow any null key or value
//Map.Entry interface provide methods to get key and value --> K getKey(),V getValue()
//Hashing is a technique of converting a large String to a small String that represents the same String
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {

		// It allows only one Key and multiple null values
		// duplicate key not allow & searching fast due to indexing
		// default size 16
		Map<Integer, String> hm = new HashMap<>();
		hm.put(1, "A");
		hm.put(2, "B");
		hm.put(3, null); // allow more than one null value
		hm.put(4, null);
		hm.put(null, "Z");
		hm.put(1, "D");
		// hm.put(null,"C");//allow only one null value
		// hm.put(1,"A"); //not allow duplicate key

		for (Map.Entry m : hm.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

		System.out.println("LinkedHashMap");

		// It maintains insertion order
		Map<Integer, String> lhm = new LinkedHashMap<>();
		lhm.put(1, "A");
		lhm.put(1, "B"); // not allow duplicate key
		lhm.put(null, "C"); // allow only one null key & multiple null value
		lhm.put(null, null);
		lhm.put(2, "C");
		lhm.put(3, null);

		for (Map.Entry m : lhm.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

		System.out.println("TreeMap");

		// TreeMap not allow null key but allow null value
		// Not allow duplicate key
		Map<Integer, String> tm = new TreeMap<>();
		tm.put(1, "A");
		// tm.put(2,"B");
		tm.put(2, null);
		// tm.put(null,null);
		tm.put(3, "B");
		tm.put(3, null);

		for (Map.Entry m : tm.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

		// HashTable not allow null Key & value
		// Hashtable is synchronized,legacy class
		// default capacity of Hashtable class is 11
		Map<Integer, String> ht = new Hashtable<>();
		ht.put(1, "A");
		ht.put(1, "A");
		ht.put(2, "B");
		ht.put(4, "A");
		// ht.put(3,null); // Not allow null key & value
		// ht.put(null,"C");
		// ht.put(null,null);

		for (Map.Entry m : ht.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}

	}

}
