package collection;

import java.util.Comparator;
import java.util.TreeSet;

class Emp {
	int id;
	String name;

	public Emp(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	class NameComparator implements Comparator<Emp> {
		@Override
		public int compare(Emp s1, Emp s2) {
			return s1.getName().compareTo(s2.getName());
		}
	}

	public static class Emplyoee {

		public static void main(String[] args) {
			TreeSet<Emp> set = new TreeSet<Emp>();

			set.add(new Emp(4, "S"));
			set.add(new Emp(3, "R"));
			set.add(new Emp(1, "D"));
			set.add(new Emp(5, "G"));
//
//			System.out.println("set");
//			Collections.sort(set, new NameComparator());
//			for (Emp ans : set) {
//				System.out.println(ans.name + " " + ans.id);
//			}
			System.out.println(set);

		}
	}
}
/*
 * class NameComparator implements Comparator<Student> {
 * 
 * @Override public int compare(Student obj1, Student obj2) { return
 * obj1.name.compareTo(obj2.name); } }
 */
