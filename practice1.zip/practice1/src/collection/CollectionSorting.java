package collection;

import java.util.ArrayList;
import java.util.Collections;

public class CollectionSorting {

	public static void main(String[] args) {
		// Create a list of strings
		ArrayList<String> al = new ArrayList<String>();
		al.add("India");
		al.add("pakistan");
		al.add("Austrilia");
		al.add("Russia");
		al.add("Amarica");

		/*
		 * Collections.sort method is sorting the elements of ArrayList in ascending
		 * order.
		 */
		Collections.sort(al);

		// Let us print the sorted list
		System.out.println("List after the use of asending  by alphabet" + " Collection.sort() :\n" + al);
		Collections.sort(al, Collections.reverseOrder());

		// Let us print the sorted list
		System.out.println("List after the use of reverse" + " Collection.sort() :\n" + al);

		al.forEach(p -> System.out.println(p));
	}
}
