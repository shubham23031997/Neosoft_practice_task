package collection;

import java.util.ArrayList;
import java.util.Collections;

// Comparable provides a single sorting sequence
// Comparable provides compareTo() method
// java.lang package
// Collections.sort(List) method.
// Comparable affects the original class when actual class modified
public class ComparableTest implements Comparable<ComparableTest> {// comparable is interface

	int rollNo;
	int age;
	String name;

	public ComparableTest(int rollNo, int age, String name) {
		this.rollNo = rollNo;
		this.age = age;
		this.name = name;
	}

	@Override
	public int compareTo(ComparableTest obj) {
		if (age == obj.age)
			return 0;
		else if (age > obj.age)
			return 1;
		else
			return -1;
	}

}

class TestComparable {
	public static void main(String[] args) {
		ArrayList<ComparableTest> cd = new ArrayList<>();
		cd.add(new ComparableTest(1, 28, "A"));
		cd.add(new ComparableTest(2, 21, "B"));
		cd.add(new ComparableTest(3, 20, "C"));

		Collections.sort(cd);

		for (ComparableTest ans : cd) {
			System.out.println(ans.rollNo + " " + ans.age + "  " + ans.name);
		}
	}
}
