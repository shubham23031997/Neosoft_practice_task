package collection;
//Set not maintain insertion order

//It not allows duplicate value
//It allows only one null value

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.NavigableSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {

		// Hashing is used to store elements in HashSet (use Hashtable for Storage)
		// hashing is technique used to return integer value for that we need to
		// override hashcode method.
		// It contains unique items
		// hashset not allowed duplicate value it allow any null values but it take only
		// one null
		Set<String> hs = new HashSet<>();
		hs.add("A");
		hs.add("B");
		hs.add(null);
		hs.add(null);

		hs.forEach(p -> System.out.println(p));
		System.out.println("HashSet will be printed");

		// LinkedHashSet class represents the LinkedList implementation
		// LinkHashset maintain insertion order
		// LinkedHashSet allowed duplicate value and null values

		Set<String> lhs = new LinkedHashSet<>();
		lhs.add("A");
		lhs.add("A");
		lhs.add(null);
		lhs.add(null);
		lhs.forEach(p -> System.out.println(p));

		System.out.println("LinkedHashSet will be printed");

		// TreeSet internal used object compareTo(obj2) but we not compare null object
		// it throws NullPointerException
		// TreeSet print value in ascending order
		// contain unique value not allow duplicate
		// TreeSet not allow null value
		Set<String> ts = new TreeSet<>();
		ts.add("A");
		ts.add("B");
		ts.add("B");
//	    ts.add(null);
//      ts.add(null);
		ts.forEach(p -> System.out.println(p));
		System.out.println("TreeSet will be printed");

		// insertion order follow
		// duplicate not allow
		// null not allow

		SortedSet<String> ss = new TreeSet<String>();

		ss.add("I");
		ss.add("A");
		ss.add("S");
		ss.add("I");

		System.out.println(ss);
		ss.remove("A");
		System.out.println("Set after removing " + "A" + ss);

		ss.forEach(p -> System.out.println(p));
		System.out.println("SortedSet will be printed");
		
		
		// insertion order follow
		// duplicate not allow
		// null not allow
//
//		NavigableSet<String> ns = new TreeSet<String>();
//
//		ss.add("I");
//		ss.add("A");
//		ss.add("S");
//		ss.add("I");
//
//		System.out.println(ss);
//		ss.remove("A");
//		System.out.println("Set after removing " + "A" + ss);

		ss.forEach(p -> System.out.println(p));
	}

}
