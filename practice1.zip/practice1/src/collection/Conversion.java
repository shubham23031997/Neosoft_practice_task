package collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

class Product {
	int id;
	String name;
	float price;

	public Product(int id, String name, float price) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

}

public class Conversion {
	public static void main(String[] args) {
		List<Product> l = new ArrayList<>();
		l.add(new Product(1, "Hp", 30000));
		l.add(new Product(2, "Dell", 40000));
		l.add(new Product(3, "Lenovo", 50000));
		l.add(new Product(4, "Mi", 20000));
		l.add(new Product(5, "Realme", 25000));
		l.add(new Product(6, "Asus", 70000));

		List<Product> l1 = l.stream().filter(p -> p.price > 20000).collect(Collectors.toList());
		for (Product p : l1) {
			System.out.println(p.id + " " + p.name + " " + p.price);
		}

		System.out.println("-------------------------------------------------------------------------");

		l.stream().filter(p -> p.id > 4)

				.forEach(p -> System.out.println(p.id + " " + p.name + " " + p.price));

		System.out.println("--------------------------------------------------------------------------");

		Integer i = (int) l.stream().filter(p -> p.price > 2000).count();

		System.out.println("count of product whose price is greater than 20000:" + i);

		System.out.println("---------------------------------------------------------------------------");

		Set<String> s1 = l.stream().filter(p -> p.price > 2000).map(p -> p.name).collect(Collectors.toSet());
		System.out.println("set of price:" + s1);

		System.out.println("---------------------------------------------------------------------------");
		List<Product> l3 = l.stream().sorted((o1, o2) -> (o1.id < o2.id) ? -1 : (o1.id > o2.id) ? 1 : 0)
				.collect(Collectors.toList());
		for (Product p : l3) {
			System.out.println(p.id + " " + p.name + " " + p.price);

			System.out.println("-----------------------------------------------------------------");
			Product min = l.stream().min((I1, I2) -> I1.price > I2.price ? 1 : -1).get();
			System.out.println(min.id + " " + min.name + " " + min.price);

			System.out.println("--------------------------------------------------------------------");
			Product max = l.stream().max((I1, I2) -> I1.price > I2.price ? 1 : -1).get();
			System.out.println(max.id + " " + max.name + " " + max.price);

			System.out.println("------------List into set---------------");
			Set<Product> s4 = l.stream().collect(Collectors.toSet());
			for (Product p1 : s4) {
				System.out.println(p1.id + " " + p1.name + " " + p1.price);
			}

			System.out.println("-------------List to Map------------------");
			Map<Integer, String> m1 = l.stream()
					.collect(Collectors.toMap(Product -> Product.id, Product -> Product.name));

			for (Integer id : m1.keySet()) {
				System.out.println("Id:" + id);
			}
			for (String name : m1.values()) {
				System.out.println("Name:" + name);
			}

			System.out.println("--------------------------------------------------------------------");

			for (Map.Entry<Integer, String> entry : m1.entrySet()) // using map.entrySet() for iteration
			{
				// returns keys and values respectively
				System.out.println("Id: " + entry.getKey() + ", Name: " + entry.getValue());
			}

			System.out.println("---------------------------------------------------------------------------");
			Set s = m1.entrySet();
			Iterator itr = s.iterator();
			while (itr.hasNext()) {
				Map.Entry m = (Entry) itr.next();
				System.out.println(m.getKey() + "  " + m.getValue());
			}

		}

	}

}
