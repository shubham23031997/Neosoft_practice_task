package collection;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class ConversionOfSetToTreeset {
	 public static void main(String[] args)
	    {
	  
	        // Get the HashSet
	        Set<Integer> setobj = new HashSet<>();
	        setobj.add(3);
	        setobj.add(22);
	        setobj.add(33);
	        setobj.add(4);
	        setobj.add(6);
	        setobj.add(7);
	        setobj.add(9);
	        setobj.add(3);
	  
	        System.out.println("HashSet: "
	                           + setobj);
	  
	        // Convert the HashSet to TreeSet
	        Set<Integer> hashSetToTreeSet
	            = new TreeSet<>(setobj);
	  
	        // Print the TreeSet
	        System.out.println("TreeSet: "
	                           + hashSetToTreeSet);
	        
//	       Set<Integer> tSet=new TreeSet<>();
//	       tSet.add(10);
//	       tSet.add(20);
//	       tSet.add(40);
//	       tSet.add(30);
//	       tSet.add(70);
//	       
//	       Set<Integer> tm=new TreeMap<>(tSet);
//	       System.out.println();
	        //empList.stream().collect(Collectors.toMap(Employee::getId, Employee::getNameString)).forEach((k,v)-> System.out.println(k +" " + v));
	       
	    }
}
