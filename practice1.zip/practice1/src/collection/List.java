package collection;

//A Collection represents unit of objects and used for non primitive data types 
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;
import java.util.stream.Collectors;

public class List {

	public static void main(String[] args) {

		// ArrayList used dynamic array
		// allow duplicate and null
		// maintain insertion order
		// non-synchronized
		// default size 10
		// load factor 0.75
		// size increase(default size*3/2)+1
		// searching fast due to indexing & add/remove take order of "n" time is slower
		// than link list
		// it have indexing
		// arraylist faster in storing and accessing data

		ArrayList<String> list = new ArrayList<>();
		list.add("A");
		list.add("B");
		list.add("C");
		list.add("D");

		list.forEach(alist1 -> System.out.println(alist1));
		System.out.println("Arraylist is displayed");

		// LinkedList used doubly linked list so that insertion and deletion is faster
		// Doubly link list contains node & node contains address of next & previous
		// node & last node contain first node address and vice versa
		// LinkedList is faster for data manipulation
		// allow duplicate and multiple null.

		LinkedList<String> ll = new LinkedList<>();
		ll.add("A");
		ll.add("B");
		ll.add("A");
		ll.add(null);
		ll.add(null);

		ll.forEach(l -> System.out.println(l));
		System.out.println("linklist is displayed");

		// Vector used dynamic array similar to ArrayList
		// vector is legacy class ,and we can iterate it by Enumeration,
		// iterator,listIterator
		// all properties are same as arraylist except It synchronized in nature

		Vector<String> v = new Vector<>();

		v.add("A");
		v.add("B");
		v.add("B");
		v.add(null);
		v.forEach(vv -> System.out.println(vv));
		System.out.println("vector is displayed");

		// Stack is subclass of vector (LIFO - Last-In-First-Out)
		Stack<String> s = new Stack<>();
		s.add("A");
		s.add("B");
		s.add("B");
		s.add(null);
		s.add(null);

		s.forEach(st -> System.out.println(st));
		System.out.println("Stack is displayed");
//     Iterator it = list.iterator();
//     while (it.hasNext()){
//         System.out.println(it.next());
//     }

		System.out.println("List to set: ");
		Set<String> set1 = list.stream().collect(Collectors.toSet());

		set1.forEach(set -> System.out.print(set + " "));

	}
}
