package collection;

import java.util.ArrayDeque;
import java.util.PriorityQueue;
import java.util.Queue;

//Deque allow Duplicate value
//Deque not allow null value
//non-synchronized in nature
public class QueueDemo {

	public static void main(String[] args) {

		// PriorityQueue doesn't allow null values
		// PriorityQueue Duplicate value allow
		Queue<String> pq = new PriorityQueue<>();
		pq.add("A");
		pq.add("B");
		pq.add("B");
		// pq.add(null); //error not allow null value
		pq.forEach(p -> System.out.println(p));

		// ArrayDeque used to add or delete the elements from both the ends.
		// ArrayDeque allow duplicate but not null value
		Queue<String> ad = new ArrayDeque<>();
		ad.add("A");
		ad.add("A");
		// ad.add(null); // error->Not allow null value
		ad.forEach(p -> System.out.println(p));

	}
}
