package collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class IterateHashmap {

	public static void main(String args[]) {
		Map<Integer, String> m = new HashMap<Integer, String>();
		m.put(1, "abc");
		m.put(2, "mno");
		m.put(3, "stu");
		m.put(4, "xyz");

		// 1. Iterating using iterators over Map.Entry<K, V>

		Set<Map.Entry<Integer, String>> m1 = m.entrySet();
		Iterator<Map.Entry<Integer, String>> i = m1.iterator();

		while (i.hasNext()) {
			Map.Entry<Integer, String> entry = i.next();
			System.out.print(entry.getKey() + ":" + entry.getValue() + " ");
		}

		System.out.println();

		// 2. Iterating over Map.entrySet() using For-Each loop :

		for (Map.Entry<Integer, String> entry : m.entrySet()) {
			System.out.print(entry + " ");
		}

		System.out.println();

		// 3. Iterating over keys or values using keySet() and values() methods 

		for (Integer keyVal : m.keySet()) {
			System.out.print(keyVal + " ");
		}

		for (String val : m.values()) {
			System.out.print(val + " ");
		}

		// 4. Using forEach(action) method : 

		m.forEach((k, v) -> System.out.print("key= " + k + ": value=" + v + " "));

		System.out.println();
	}
}
