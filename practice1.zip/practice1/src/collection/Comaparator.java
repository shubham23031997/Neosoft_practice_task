package collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

//Comparator provides multiple sorting sequence
//Comparator doesn't affect the original class when change in actual class
//Comparator provides compare() method
// java.util package
//Collections.sort(List, Comparator)
public class Comaparator {//functional interface  

}

class Student {
	int rollNo;
	int age;
	String name;

	public Student(int rollNo, int age, String name) {
		this.rollNo = rollNo;
		this.age = age;
		this.name = name;
	}
}

class AgeComparator implements Comparator<Student> {
	@Override
	public int compare(Student obj1, Student obj2) {
		if (obj1.age == obj2.age)
			return 0;
		else if (obj1.age > obj2.age)
			return 1;
		else
			return -1;
	}
}

class NameComparator implements Comparator<Student> {
	@Override
	public int compare(Student obj1, Student obj2) {
		return obj1.name.compareTo(obj2.name);
	}
}

class Test {
	public static void main(String[] args) {
		ArrayList<Student> st = new ArrayList<>();
		st.add(new Student(1, 29, "Sham"));
		st.add(new Student(2, 23, "Aim"));
		st.add(new Student(3, 45, "Mill"));

		System.out.println("Sorting By Name");
		Collections.sort(st, new NameComparator());
		for (Student ans : st) {
			System.out.println(ans.rollNo + " " + ans.name + " " + ans.age);
		}

		System.out.println("Sorting by Age");
		Collections.sort(st, new AgeComparator());
		for (Student ans : st) {
			System.out.println(ans.rollNo + " " + ans.name + " " + ans.age);
		}

	}
}
