package fullerton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class RemovedDuplicatesByStreamApi {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		al.add(10);
		al.add(20);
		al.add(10);
		al.add(30);
		al.add(40);
		al.add(30);
		al.add(null);
		al.add(null);
		System.out.println(al);
		List<Integer> l = al.stream().distinct().collect(Collectors.toList());
		System.out.println(l);
		List<Integer> l1 = al.stream().filter(al1 -> al1 != null).distinct().collect(Collectors.toList());
		System.out.println(l1);

		int[] arr = { 1, 2, 3, 4, 4, 3, 6, 7, 6 };
		System.out.println(arr);
		// ArrayList<Integer> arr1=new ArrayList<Integer>(arr);

		Arrays.stream(arr).distinct().forEach(val -> System.out.print(val + " "));
	}
}
