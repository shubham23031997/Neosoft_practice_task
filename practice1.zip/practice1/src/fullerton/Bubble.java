package fullerton;

public class Bubble {
	static int bubblesort(int[] arr) {
		int n = arr.length;
		int temp = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 1; j < n - 1; j++) {
				if (arr[j - 1] > arr[j]) {
					temp = arr[j];
					arr[j] = arr[j - 1];
					arr[j - 1] = temp;
				}
			}
		}
	
		return 0;
	}

	public static void main(String[] args) {
		int i[] = { 20, 10, 30, 50, 40, 60 };
		System.out.println("array before bubblesort");
		for (int j = 0; j < i.length; j++) {
			System.out.println(i[j]);
		}
		System.out.println();
		bubblesort(i);
		System.out.println("array after bubblesort");
		for (int j = 0; j < i.length; j++) {
			System.out.println(i[j]);
		}
	}
}
