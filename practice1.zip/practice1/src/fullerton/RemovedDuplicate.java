package fullerton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemovedDuplicate {
	public static void main(String[] args) {

		List<Integer> l = new ArrayList<>(Arrays.asList(10, null, 20, 30, 10, 40, null, 20));
		Set<Integer> s = new LinkedHashSet<Integer>();
		s.addAll(l);
		System.out.println(s);
//		int[] a = new int[l.size()];
//		List<Integer> l2 = new ArrayList<>();
//		for (int i = 0; i < l.size(); i++) {
//			for (int j = i; j < l.size(); j++) {
//				if (a[i] == a[j]) {
//					l2.add(a[j]);
//				} else
//					continue;
//			}
//		}
//
//		for (int i = 0; i < l.size(); i++) {
//			System.out.println(l2);
//		}

	}
}
