package fullerton;

public class BubbleSort {
	static void bubbleSort(int[] arr) {
		int n = arr.length;
		int temp = 0;
		for (int i = 0; i < n; i++) {
			for (int j = 1; j < n - 1; j++)
				if (arr[j - 1] > arr[j]) {
					temp = arr[j - 1];
					arr[j - 1] = arr[j];
					arr[j] = temp;
				}
		}

	}

	public static void main(String[] args) {
		int i[] = { 30, 20, 40, 50, 70, 60 };
		System.out.println("array before bubblesort");
		for (int j = 0; j < i.length; j++) {
			System.out.println(i[j] + "");
		}
		System.out.println();
		bubbleSort(i);
		System.out.println("array after bubblesort");
		for (int j = 0; j < i.length; j++) {
			System.out.println(i[j] + "");
		}
	}
}
