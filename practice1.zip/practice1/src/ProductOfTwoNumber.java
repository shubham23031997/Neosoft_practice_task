import java.util.ArrayList;
import java.util.List;

public class ProductOfTwoNumber {

	public static void main(String[] args) {
		List<Integer> numlist = new ArrayList<>();
		numlist.add(1);
		numlist.add(2);
		// Write a code to find the product of two elements from list.
//		int product = 1;
//		for (int i = 0; i < numlist.size(); i++) {
//			for (int j = i + 1; j < numlist.size(); j++) {
//				product = product * numlist.get(i) * numlist.get(j);
//
//			}
//		}
		int product = numlist.stream().reduce(1, (a, b) -> a * b);

		System.out.println("Product of two elements: " + product);

	}

}
