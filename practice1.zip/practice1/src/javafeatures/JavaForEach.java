package javafeatures;

// Whenever we traverse through a Collection, we need to create an Iterator
// forEach() method is in Iterable interface

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;

public class JavaForEach {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(100);
		list.add(200);
		list.add(300);

		list.forEach(x -> System.out.println(x));

//        list.forEach(new Consumer<Integer>() {
//            @Override
//            public void accept(Integer value) {
//               System.out.println(value);
//            }
//        });

//        Iterator<Integer> it = list.iterator();
//        while(it.hasNext()){
//            Integer i = it.next();
//            System.out.println(i);
//        }  	

	}
}
