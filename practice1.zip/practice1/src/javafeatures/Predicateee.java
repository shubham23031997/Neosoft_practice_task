package javafeatures;

import java.util.function.Predicate;

public class Predicateee {
	public static void main(String[] args) {

		Predicate<Integer> predicate = (a) -> {
			if (a % 2 == 0) {
				return true;
			} else {
				return false;
			}
		};

//      predicate.test(3);
		System.out.println(predicate.test(4));
	}
}