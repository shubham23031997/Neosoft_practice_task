package javafeatures;

class ThreadDemo {

	void s() {
		Runnable runnable = () -> System.out.println("msg called");
		new Thread(runnable).start();
	}
}

public class RunnableLamdaExample {

	public static void main(String[] args) {
		ThreadDemo threadDemo = new ThreadDemo();
		threadDemo.s();

//		Thread thread = new Thread(threadDemo);

//		Thread thread = new Thread(new ThreadDemo());
//		thread.start();

// 		Runnable run = () -> System.out.println("msg");
//		Runnable runnable = () -> System.out.println("msg called");
//		new Thread(runnable).start();
	}
}