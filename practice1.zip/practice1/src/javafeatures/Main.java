package javafeatures;

public class Main {// implements Anonymous

	public static void main(String[] args) {
//		Test t=new Test();
//		t.show();//this is use for implementing interface in class

//	[	Anonymous obj = new Anonymous() {
//			public void show() {
//				System.out.println("this is show method");
//			}
//		};]// this is the inner class of interface which name same a name of interface.
//		obj.show();

		Anonymous lamda = () -> System.out.println("This is Anonymous");
		lamda.show();

		lamda.display();// we can call default method with reference of anonymous class

		Anonymous.print();
	}

//	@Override
//	public void show() {
//
//	}

}