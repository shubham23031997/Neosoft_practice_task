package javafeatures.methodreferance;

import java.util.function.Function;

public class MethodReferacesDemo {

	public static void main(String[] args) {
		// method references for static method
		// lamda expression
		Function<Integer, Double> function = (input) -> Math.sqrt(input);
		System.out.println(function.apply(69));

		// using method reference
		Function<Integer, Double> functionMethRef = Math::sqrt;
		System.out.println(functionMethRef.apply(4));
	}
}