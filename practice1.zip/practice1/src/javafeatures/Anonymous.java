package javafeatures;
//anonymous class is  nested class without name

//Functional interface is contains only one abstract method except static and default method
//They can have only one functionality to exhibit.
 @FunctionalInterface // without this annotation we unable to get function interface have other than
						 // static and default method
public interface Anonymous {
	void show();

	// void print1();
	
	default void display() {
		System.out.println("This is Static method");
	}

	static void print() {
		System.out.println("This is default method");
	}
}