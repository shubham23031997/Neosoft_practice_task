package javafeatures;

interface Printable {
	public abstract void print(String msg);
}

public class MethodReferance {

	public static void main(String[] args) {
		Printable printable = (String msg) -> System.out.println(msg);
		printable.print("hello");
		Printable printable2 = System.out::print;
		printable2.print("hhhhhh");

	}

}
