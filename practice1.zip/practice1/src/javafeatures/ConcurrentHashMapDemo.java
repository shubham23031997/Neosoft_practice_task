package javafeatures;

//ConcurrentHashMap class is thread-safe
//i.e. multiple threads can operate on a single object without any complications
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapDemo {

	public static void main(String args[]) {

		ConcurrentHashMap<Integer, String> obj = new ConcurrentHashMap<>();

		obj.put(101, "All");
		obj.put(102, "the");
		obj.put(103, "best");

		obj.putIfAbsent(101, "world");

		obj.remove(101, "All");

		obj.replace(102, "the", "is");

		System.out.println(obj);
	}
}
