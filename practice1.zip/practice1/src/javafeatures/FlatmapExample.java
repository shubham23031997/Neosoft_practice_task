package javafeatures;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FlatmapExample {
	public static void main(String[] args) {
		List<String> list1 = Arrays.asList("a", "b");
		List<String> list2 = Arrays.asList("c", "d");
		List<String> list3 = Arrays.asList("e", "f");
		// we can convert multiple list to string list with help of flatmap

		System.out.println(Stream.of(list1, list2, list3).flatMap(List::stream).collect(Collectors.toList()));

		Map<String, List<Integer>> m1 = new LinkedHashMap<>();
		m1.put("one", Arrays.asList(1, 2, 3));
		m1.put("two", Arrays.asList(4, 5, 6));
		m1.put("three", Arrays.asList(7, 8, 9));
		System.out.println(m1);
		System.out.println(m1.values().stream().flatMap(List::stream).collect(Collectors.toList()));

		List<Map<String, Integer>> listofmap = new ArrayList<>();
		Map<String, Integer> mm = new HashMap<>();
		mm.put("one", 11);
		mm.put("two", 12);
		Map<String, Integer> nn = new HashMap<>();
		nn.put("three", 13);
		nn.put("four", 14);
		listofmap.add(nn);
		listofmap.add(mm);

		System.out
				.println(listofmap.stream().map(Map::values).flatMap(Collection::stream).collect(Collectors.toList()));
	}
}