package javafeatures;
// Java Stream API for Bulk Data Operations on Collections

// to perform filter/map/reduce like operations with the collection.
// Stream API will allow sequential as well as parallel execution

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class JavaStreamAPI {

	public static void main(String[] args) {

		List<Integer> list = new ArrayList<>();

		for (int i = 1; i < 100; i++)
			list.add(i);

		// Sequential Execution
		Stream<Integer> seq = list.stream();
		Stream<Integer> seqValue = seq.filter(p -> p > 90);
		seqValue.forEach(p -> System.out.println("Sequential :" + p));

		// parallel execution
		Stream<Integer> par = list.parallelStream();
		Stream<Integer> parVal = par.filter(p -> p > 90);
		parVal.forEach(p -> System.out.println("Parallel :" + p));

		// Creating a list of Integers
		List<Integer> list1 = Arrays.asList(3, 4, 6, 12, 20);

		// elements that are divisible by 5
		// Using Stream filter(Predicate predicate)
		list1.stream().filter(num -> num % 5 == 0).forEach(System.out::println);
	}

}
