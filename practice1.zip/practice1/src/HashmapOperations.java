import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class HashmapOperations {

	public static void main(String[] args) {
		Map<Integer, String> map1 = new HashMap<>();
		map1.put(1, "A");
		map1.put(2, "B");
		map1.put(3, "C");
		map1.put(4, "D");
		Map<Integer, String> map2 = new HashMap<>();
		map2.put(1, "A");
		map2.put(2, "B");
		map2.put(3, "C");

		Map<Integer, String> map3 = new HashMap<>();
		map3.put(1, "A");
		map3.put(2, "B");
		map3.put(3, "C");
		map3.put(4, "D");

		System.out.println(map1.equals(map3));
		System.out.println(map1.equals(map2));

		HashSet<Integer> containskey = new HashSet<>(map1.keySet());
		containskey.addAll(map2.keySet());
		System.out.println(containskey);
		containskey.removeAll(map2.keySet());
		System.out.println(containskey);
		// comparing values by using arraylist
		System.out.println(new ArrayList<String>(map1.values()).equals(new ArrayList<>(map2.values())));
		System.out.println(new ArrayList<String>(map1.values()).equals(new ArrayList<>(map3.values())));
	}

}
