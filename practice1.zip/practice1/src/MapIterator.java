import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MapIterator {
	public static void main(String[] args) {
		Map<Integer, String> hashmap = new HashMap<>();

		hashmap.put(1, "shubham");
		hashmap.put(2, "kaustubh");
		hashmap.put(3, "hno");
		hashmap.put(4, "mno");
		hashmap.put(null, "aaditya");
		hashmap.put(null, "vimlesh");// override //null key is always on zeroth index

		System.out.println(hashmap);

//		Collections.sort(hashmap);

		List<String> list = new ArrayList<>(hashmap.values());
		Collections.sort(list);

		System.out.println(list);

		for (Map.Entry<Integer, String> entry : hashmap.entrySet()) {
			System.out.println("key= " + entry.getKey() + "value= " + entry.getValue());
		}
//==========================================================================================

		for (Integer str : hashmap.keySet()) {
			System.out.println("key= " + str);
		}
		for (String str1 : hashmap.values()) {
			System.out.println("values= " + str1);
		}

//==========================================================================================

		Iterator<Map.Entry<Integer, String>> itr = hashmap.entrySet().iterator();
		while (itr.hasNext()) {
			Map.Entry<Integer, String> entry = itr.next();
			System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
		}

// ==========================================================================================
		hashmap.forEach((k, v) -> System.out.println("key= " + k + "value= " + v));
	}
}
