package String;

public class ReverseString1 {
	public String reverseString(String input) {
		StringBuilder sb = new StringBuilder(input);
		return sb.reverse().toString();
	}

	public static void main(String[] args) {
		ReverseString1 rs = new ReverseString1();
		System.out.println(rs.reverseString("shubham"));
	}
}