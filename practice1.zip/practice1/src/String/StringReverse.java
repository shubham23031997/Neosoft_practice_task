package String;

public class StringReverse {
	public String reverseString(String input) {
		StringBuilder reversed = new StringBuilder(input);
		return reversed.reverse().toString();
	}

	public static void main(String[] args) {
		StringReverse reverse = new StringReverse();
		System.out.println(reverse.reverseString("shubham"));
		System.out.println(reverse.reverseString1("Nivrutti"));
		System.out.println(reverse.reverseString2("Nerkar"));
	}

	public String reverseString1(String input) {
		if (input.isEmpty()) {
			return input;
		} else {
			return reverseString1(input.substring(1)) + input.charAt(0);
		}
	}

	public String reverseString2(String input) {
		char[] chars = input.toCharArray();
		int left = 0;
		int right = chars.length - 1;

		while (left < right) {
			// Swap characters at left and right indices
			char temp = chars[left];
			chars[left] = chars[right];
			chars[right] = temp;

			// Move the indices towards each other
			left++;
			right--;
		}

		return new String(chars);
	}

}
