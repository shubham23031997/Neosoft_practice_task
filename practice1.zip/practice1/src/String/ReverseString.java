package String;

public class ReverseString {
	public String reverse(String input) {
		if (input.isEmpty()) {
			return input;
		} else {
			return reverse(input.substring(1)) + input.charAt(0);
		}
	}

	public static void main(String args[]) {
		ReverseString reverseString = new ReverseString();
		System.out.println(reverseString.reverse("shubham"));
	}
}
