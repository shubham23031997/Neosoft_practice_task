package practice1;

public class CheckLenghtWithOutLengthMethod {
	public static void main(String[] args) {
		String s1 = "shubham";
		String s2 = "";
		System.out.println(s1.compareTo(s2));
		System.out.println(s1 + 10);// shubham10
		System.out.println(s1 + 10 + 20);// shubham1020
		System.out.println(10 + 20 + s1);// 30shubham
		// its works left to right if string comes in starting in it concats but if
		// integers came first then its doing addition
		System.out.println(s1 + 20 / 10);// shubham2
		// System.out.println(s1+10-5);// error
		System.out.println(s1.startsWith("u"));// false
		System.out.println(s1.charAt(2));//

		StringBuffer sb = new StringBuffer();
		System.out.println(sb.capacity());// 16 default capacity
		StringBuffer sb1 = new StringBuffer("shubham");
		System.out.println(sb1.capacity());// 16+7(length of string)

		System.out.println(sb.append("mali"));

	}
}
