package practice1;

import java.util.Scanner;

public class ExceptionExample {
	public static void main(String args[]) {
		String str = "beginnersbook.com";

		// NumberFormatException
		// int num = Integer.parseInt(str);
		int dividend, divisor;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the dividend");
		dividend = sc.nextInt();

		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter the divisor");
		divisor = sc1.nextInt();

		try {

			int div = dividend / divisor;
			System.out.println("Quotient: " + div);

		} catch (ArithmeticException e) {
			System.out.println("Do not enter divisor as zero.");
			System.out.println("Error Message: " + e);
		}
	}
}
