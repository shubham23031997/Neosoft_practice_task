package practice1;

class SingletonObject {
	// Static variable reference of single_instance
	private static SingletonObject single_instance = null;

	public String s;

	// Here we will be creating private constructor
	private SingletonObject() {
		s = "Hello I am a string part of Singleton class";
	}

	// Static method to create instance of Singleton class
	public static SingletonObject getInstance() {
		if (single_instance == null)
			single_instance = new SingletonObject();

		return single_instance;
	}
}

public class Singleton {

	public static void main(String args[]) {
		// Instantiating Singleton class with variable x,y,z
		SingletonObject x = SingletonObject.getInstance();
		SingletonObject y = SingletonObject.getInstance();

		SingletonObject z = SingletonObject.getInstance();

		System.out.println("Hashcode of x is " + x.hashCode());
		System.out.println("Hashcode of y is " + y.hashCode());
		System.out.println("Hashcode of z is " + z.hashCode());

	}
}
