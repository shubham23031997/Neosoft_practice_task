package practice1;
class Vehicle{
	Vehicle run() {
		System.out.println("vehicle is running");
		return this;
	}
}
public class Overide extends Vehicle{
	Overide run() {
		System.out.println("bike is running");
		return this;
	}
	public static void main(String[] args) {
		Overide o=new Overide();
		o.run();
		Vehicle v=new Vehicle();
		v.run();

	}

}
