package practice1;

import java.util.Arrays;

public class DisplayEvenAndOdd {
	// 2,4,6,8,20,1,3,7
	public static void main(String[] args) {
		int array[] = { 1, 2, 4, 3, 6, 7, 8, 20 };
		Arrays.sort(array);
		sortEvenOdd(array);
	}

	public static void sortEvenOdd(int arr[]) {
		int[] a = new int[arr.length];
		int index = 0;
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 == 0) {
				a[index] = arr[i];
				index++;
			}

		}
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] % 2 != 0) {
				a[index] = arr[i];
				index++;
			}

		}
		for (int i = 0; i < arr.length; i++) {
			System.out.print(a[i] + ",");
		}

	}

}
