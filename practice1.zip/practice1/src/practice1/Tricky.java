package practice1;

public class Tricky {
	int String = 10;
	char c=87;
	char number='b';
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
