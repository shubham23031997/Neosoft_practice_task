package practice1;

public class StringFormatter {
//	public static String reverseString(String str) {
//		StringBuilder sb = new StringBuilder(str);
//		sb.reverse();
//		return sb.toString();
//	}
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		System.out.println(StringFormatter.reverseString("my name is shubham"));
//	}
	public static String reverseString(String str) {
		char ch[]=str.toCharArray();
		String rev="";
		for(int i=ch.length-1;i>=0;i--) {
			rev=rev+ch[i];
		}
		return rev;
	}
	public static void main(String args[]) {
		System.out.println(StringFormatter.reverseString("my name is shubham"));
	}
}
