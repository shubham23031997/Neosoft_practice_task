package practice1;

public class A {
	final int a;

	A(int a) {
		this.a = a;
	}

	public static void main(String[] args) {
		String s = "shubham";
		A a = new A(3);
		System.out.println(s.concat("mali"));
		
	}

}
