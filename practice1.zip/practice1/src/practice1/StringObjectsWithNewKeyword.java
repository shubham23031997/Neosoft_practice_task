package practice1;

import java.util.Hashtable;
import java.util.function.Consumer;

//import org.openjdk.jol.vm.VM;
//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class StringObjectsWithNewKeyword {
	public static void main(String[] args) {
//		SpringApplication.run(StringObjectsWithNewKeyword.class, args);

		String str1 = "str";
		String str2 = "str";
		String str3 = new String("str");

		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str3.hashCode());

		System.out.println("......................................");

//		System.out.println(VM.current().addressOf(str1));  123456
//		System.out.println(VM.current().addressOf(str2));  123456
//		System.out.println(VM.current().addressOf(str3.intern()); 
//		System.out.println(VM.current().addressOf(str3)); 

		System.out.println(str1 == str2);
		System.out.println(str1 == str3);
		System.out.println(str2 == str3);// here checking address and value

		System.out.println(str1.equals(str2));
		System.out.println(str1.equals(str3));
		System.out.println(str2.equals(str3));// here checking only value

	}
}
/*
 * <dependency> <groupId>org.openjdk.jol</groupId>
 * <artifactId>jol-core</artifactId> <version>0.10</version> </dependency>
 */
// we have to add this dependency in springboot application so that we can check address of object
