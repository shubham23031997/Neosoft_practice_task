package practice1;

import java.util.Arrays;

public class MergeTwoArray {

	public static void main(String[] args) {		
		
		// TODO Auto-generated method stub
		int array1[] = { 10, 20, 30, 40, 50 };
		int array2[] = { 8, 19, 28, 39, 51 };
		int FinalArray[] = new int[array1.length + array2.length];
		System.arraycopy(array1, 0, FinalArray, 0, array1.length);
		System.arraycopy(array2, 0, FinalArray, array1.length, array2.length);
		Arrays.sort(FinalArray);
		System.out.println(Arrays.toString(FinalArray));
//		for(int element: FinalArray)
//		{
//			System.out.println(element);
//		}
	}

}
