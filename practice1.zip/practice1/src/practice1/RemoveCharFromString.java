package practice1;

public class RemoveCharFromString {
	/*
	 * public static void main(String[] args) { String str = "Neosoft"; char o =
	 * 'o'; removeChar(str, o); }
	 * 
	 * public static void removeChar(String str, char c) { String string = "";
	 * 
	 * for (int i = 0; i < str.length(); i++) { if (str.charAt(i) != 'o') { string =
	 * string + str.charAt(i); } } System.out.println(string); }
	 */
	public static void main(String[] args) {
		String str = "neosoft";
		char o = 'o';
		removeChar(str, o);
	}

	public static void removeChar(String str, char c) {
		String string = "";
		for (int i = 0; i < str.length(); i++) {
			if (str.charAt(i) != 'o') {
				string = string + str.charAt(i);
			}
		}
		System.out.println(string);
	}
}
