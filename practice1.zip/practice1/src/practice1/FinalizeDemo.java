package practice1;

public class FinalizeDemo {

	public static void main(String[] args) {

		FinalizeDemo f1 = new FinalizeDemo();
		FinalizeDemo f2 = new FinalizeDemo();

		f1 = new FinalizeDemo();
		// 2.By reassigning the reference variable
		f1 = f2;
		System.out.println(f2.hashCode());

		System.out.println(f1.hashCode());
		// 1.By nullifying the reference variable
		f1 = null;

		System.gc();
		System.out.println("garbage collection called");

		// 3.By creating objects inside a method
		m1();
	}

	@Override
	protected void finalize() {
		System.out.println("Finalize method called");
	}

	public static void m1() {
		FinalizeDemo s1 = new FinalizeDemo();
		FinalizeDemo s2 = new FinalizeDemo();
	}
}
/*
 * 1.By nullifying the reference variable 2.By reassigning the reference
 * variable 3.By creating objects inside a method 4.Island of Isolation
 */