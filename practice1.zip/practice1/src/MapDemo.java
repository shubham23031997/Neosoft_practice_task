import java.util.HashMap;
import java.util.Map;

public class MapDemo {

	public static void main(String[] args) {
		HashMap<Integer, String> map = new HashMap<>();
		map.put(1, "shubham");
		map.put(3, "ganesh");
		map.put(2, "kaustubh");

		for (Map.Entry<Integer, String> entry : map.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());

		}

	}
}