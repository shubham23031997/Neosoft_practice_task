
public class StringConcat {

	public static void main(String[] args) {
		String s1 = "Hello";
		String s2 = "World";
		String s3 = s1 + s2; // s3 is a new string, s1 and s2 are not modified
		String s4=s1.concat("shubham");
		System.out.println(s3);
		System.out.println(s4);
	}

}
