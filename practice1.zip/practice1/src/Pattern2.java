/*
public class Pattern2 {

    public static void main(String[] args) {

        for (int i = 1; i <= 4; i++) {
            int k = i - 1;
            for (int j = 1; j <= i; j++)//j=1,k=2; j=2,k=2
            {
                k++;
                System.out.print(k);
            }
            System.out.println("");
        }
    }
}*/
/*
1
23
345
4567
*/
/*
public class Pattern2 {

    public static void main(String[] args) {

        for (int i = 1; i <= 4; i++) {

            for (int j = 1; j <= i; j++)//j=1,k=2; j=2,k=2
            {
                System.out.print(j);
            }
            System.out.println("");
        }
    }
}
*/

/*
1
22
333
4444
if print j then output is
1
12
123
1234
*/

/*
public class Pattern2 {

    public static void main(String[] args) {

        for (int i = 1; i <= 4; i++) {
            for (int j = 4; j >= i; j--)//j=1,k=2; j=2,k=2
            {
                System.out.print(i);
            }
            System.out.println("");
        }
    }
}

 */
/*
        4321
        432
        43
        4
if we print i
1111
222
33
4
 */
/*
public class Pattern2 {

    public static void main(String[] args) {

        for (int i = 1; i <= 4; i++) {
            for (int k = 1; k <= i; k++)//j=1,k=2; j=2,k=2
            {
                System.out.print(" ");
            }

            for (int j = 4; j >= i; j--)//j=1,k=2; j=2,k=2
            {
                System.out.print(i);
            }
            System.out.println("");
        }
    }
}

         1111
          222
           33
            4
*/

/*
public class Pattern2 {
    public static void main(String[] args) {
        for (int i = 1; i <= 4; i++) {
            for (int k = 3; k >= i; k--) {
                System.out.print(" ");
            }
            for (int j = 1; j <= i; j++)//j=1,k=2; j=2,k=2
            {
                System.out.print(" "+i);
            }
            System.out.println("");
        }
    }
}
           1
         2   2
       3   3   3
     4   4   4   4
*/
/*
public class Pattern2 {

    public static void main(String[] args) {

        for (int i = 6; i <=9 ; i++) {

            for (int j = i; j <= 9; j++) {

                System.out.print(j);
            }
            for (int k=5;k>0;k--){
                System.out.print(k);
            }
            System.out.println();
        }
        for(int x=5;x>=1;x--)
        {
            for (int y=x;y>0;y--){
                System.out.print(y);
        }
            System.out.println();
        }
    }
}
678954321
        78954321
        8954321
        954321
        54321
        4321
        321
        21
        1
        */


import java.util.Scanner;

public class Pattern2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int row = sc.nextInt();

        int i, j;

        for (i = 1; i <= row / 2; i++) {

            for (j = 1; j <= row / 2 - i; j++) {

                System.out.print(" ");

            }

            for (j = 1; j <= i; j++) {

                System.out.print(j);

            }

            for (j = i - 1; j >= 1; j--) {

                System.out.print(j);

            }

            System.out.println();

        }


//        for (i = row / 2; i >= 1; i--) {
//
//            for (j = 1; j <= row / 2 - i; j++) {
//
//                System.out.print(" ");
//            }
//        }


        for (i = row / 2; i >= 1; i--) {

            for (j = 1; j <= row / 2 - i; j++) {

                System.out.print(" ");

            }

            for (j = 1; j <= i; j++) {

                System.out.print(j);

            }

            for (j = i - 1; j >= 1; j--) {

                System.out.print(j);

            }

            System.out.println();

        }

    }

}

