
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCExample {
	static final String DB_URL = "jdbc:mysql://localhost/TUTORIALSPOINT";
	static final String USER = "guest";
	static final String PASS = "guest123";
	static final String QUERY = "SELECT item_no, item_name,item_quantity,item_rate FROM ItemTable";

	public static void main(String[] args) {
		// Open a connection
		try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
				Statement stmt = conn.createStatement();) {
			String sql = "UPDATE ItemTable "
					+ "SET item_name=laptop,item_quantity=1,item_rate=50000 WHERE item_no in (10)";
			stmt.executeUpdate(sql);
			ResultSet rs = stmt.executeQuery(QUERY);
			while (rs.next()) {
				// Display values
				System.out.print(", item_name: " + rs.getString("laptop"));
				System.out.print(", item_quantity: " + rs.getInt(1));
				System.out.println(", item_rate: " + rs.getInt(50000));
			}
			rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}