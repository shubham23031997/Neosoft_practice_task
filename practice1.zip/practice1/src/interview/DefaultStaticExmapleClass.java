package interview;


	interface DefaultStaticExampleInterface {
		   default void show() {
		      System.out.println("In Java 8- default method - DefaultStaticExampleInterface");
		   }
		   static void display() {
		      System.out.println("In DefaultStaticExampleInterface I");
		   }
		}
	class Main  implements DefaultStaticExampleInterface {
		}
	
		public class DefaultStaticExmapleClass {
		   static void main(String args[]) {
		      DefaultStaticExampleInterface.display();
			 
		      Main m = new Main();
		     
		      // Call default method on Class
		      m.show();
		   }
		}

