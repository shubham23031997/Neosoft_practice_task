package interview;

class Parent {
	public Parent() {
	}

	public void print() {
	}
}

public class ContructorInfo extends Parent {
	public void Parent() {
	}

	public void print() {
	}

	public static void main(String[] args) {
		ContructorInfo c1 = new ContructorInfo(); // allowed
//	    	ContructorInfo c2 = new Parent(); // not allowed
	}
}
