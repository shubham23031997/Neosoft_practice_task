import java.util.Scanner;

public class Shortform {
    public static void main(String args[]) {
//        System.out.print("enter the string :");
//        Scanner sc = new Scanner(System.in);
//        String str = sc.next();

        String str = "Shubham nivrutti mali";
        if (str.length() == 0)
            return;

        System.out.print(Character.toUpperCase(
                str.charAt(0)));

        for (int i = 1; i < str.length() ; i++)
            if (str.charAt(i) == ' ')
                System.out.print(" " + Character.toUpperCase(
                        str.charAt(i + 1)));
    }
}