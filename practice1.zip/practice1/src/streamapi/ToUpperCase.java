package streamapi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ToUpperCase {

	public static void main(String[] args) {
		System.out.println("converting lower cases string to uppercase");
		List<String> listofString = new ArrayList<String>();
		listofString.add("shubham");
		listofString.add("kaustubh");
		listofString.add("vimlesh");
		listofString.add("ganesh");
		System.out.println(listofString);

		ArrayList<String> arrlist = (ArrayList<String>) listofString.stream().map(String::toUpperCase)
				.collect(Collectors.toList());
		System.out.println(arrlist);
		System.out.println();
		System.out.println("converting number into square of that number");
		List<Integer> convertToSquare = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
		System.out.println(convertToSquare);
		List<Integer> ll = convertToSquare.stream().map(i -> i * i).collect(Collectors.toList());
		System.out.println(ll);
		System.out.println();

	}

}
