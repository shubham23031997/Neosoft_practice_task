package streamapi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class FlatMapDemo {

	public static void main(String[] args) {
		List<String> l1 = new ArrayList<>(Arrays.asList("shubham", "nivrutti", "mali"));
		List<String> l2 = new ArrayList<>(Arrays.asList("shubham", "vishnu", "bankar"));
		List<String> l3 = new ArrayList<>(Arrays.asList("saurabh", "nivrutti", "mali"));
		List<String> l4 = new ArrayList<>(Arrays.asList("ram", "shyam", "yadav"));
		List<List<String>> l5 = new ArrayList<>();
		l5.add(l1);
		l5.add(l2);
		l5.add(l3);
		l5.add(l4);
		System.out.println(l5);

		List<String> l6 = l5.stream().flatMap(l7 -> l7.stream()).filter(t -> t.endsWith("am")).toList();//this in java 16
//				.collect(Collectors.toList());
		System.out.println(l6);

	}

}
