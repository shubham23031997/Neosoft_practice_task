package streamapi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//streams are related to collection frameworks/(group of objects). 
//stream reduced the code length.
//stream api is basically perform bulk operations and process the objects of collections

public class StreamApi {

	public static void main(String[] args) {

		List<Integer> list = List.of(2, 4, 53, 6, 75, 44);
//		list.add(34);
//		list.add(45);
//		list.add(366);
//		list.add(77);
		// this throws unsupportedOperation Exception.
		System.out.println(list);

		List<Integer> list1 = new ArrayList<>(Arrays.asList(1, 2, 3, 45, 67, 8));
		list1.add(12);

		list1.add(12);
		System.out.println(list1);

		List<Integer> list2 = new ArrayList<>();
		list2.add(12);
		list2.add(null);
		list2.add(12);
		System.out.println(list2);

		// create list and filter all even numbers from list and put into another list
		List<Integer> Listeven = new ArrayList<>();
		for (Integer newList : list1) {
			if (newList % 2 == 0) {
				Listeven.add(newList);
			}
		}
		System.out.println(Listeven);

		// using stream
		Stream<Integer> stream = list1.stream();
		List<Integer> ll = stream.filter(x -> x % 2 == 0).collect(Collectors.toList());
		System.out.println(ll);
	}

}