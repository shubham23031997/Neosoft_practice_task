package streamapi;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class CountOfEachCharacter {

	public static void main(String[] args) {
		String input="ilovemyindia";
		String[] array= input.split("");
		
		System.out.println(Arrays.toString(array));
		
		System.out.println(Arrays.stream(array).collect(Collectors.groupingBy(s->s)));
		
		Map<String, Long> map=Arrays.stream(array).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println(map);
	}

}
