package streamapi;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

class Employee{
	int id;
	String name;
	int salary;
	public Employee(int id,String name,int salary) {
		this.id=id;
		this.name=name;
		this.salary=salary;		
	}
	
	@Override
	public String toString() {
		return "id=" + id + ", name=" + name + ", salary=" + salary ;
	}

	public int getId() {
		return id;	
	}
	public void setId(int id) {
		this.id=id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
}
public class MaxSalary {

	public static void main(String[] args) {
	List<Employee> employees=List.of(new Employee(1, "shubham", 1000),
			new Employee(2, "akhilesh", 2000),
			new Employee(3, "kunal", 1500));
	
	Employee employee1=employees.stream().max(Comparator.comparing(Employee::getSalary)).get();
	System.out.println(employee1);
	
	Optional<Employee> employee2 =employees.stream().collect(Collectors.maxBy(Comparator.comparing(Employee::getSalary)));
	System.out.println(employee2);
	
	Optional<Employee> employee3 = employees.stream()
             .max((e1, e2) -> Double.compare(e1.getSalary(), e2.getSalary()));
	 System.out.println(employee3);


	}

}
