package streamapi;

public class Hello {

	public static void main(String[] args) {

	}

}
