package accessmodifiers;

//all private method fields are accessible within the class only
class PrivateClass {
	// outer class can't be private only inner class are allow private
	private PrivateClass() {
	}

	private int number = 40;

	@SuppressWarnings("unused")
	private void message() {
		System.out.println("private method called");
	}
}

public class PrivateInfo {
	public static void main(String args[]) {
		// PrivateClass obj = new PrivateClass();
		// here we can not access private constructor outside the class

		// System.out.println(obj.number);
		// here we can not access private data members outside the class

		// obj.message();
		// Compile Time Error
		// here we can not access private method outside the class
	}
}
