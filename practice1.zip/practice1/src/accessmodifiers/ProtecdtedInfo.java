package accessmodifiers;

import newpack.Parent;

public class ProtecdtedInfo extends Parent {

	public static void main(String[] args) {

		ProtecdtedInfo obj1 = new ProtecdtedInfo();
		obj1.getInfo();
		// here we access protected method outside the class by inheritance
	}
}
