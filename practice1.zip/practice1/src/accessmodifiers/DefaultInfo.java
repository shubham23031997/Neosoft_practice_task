package accessmodifiers;

class DefaultDemo {
	// by default every class is default class
	void message() {
		System.out.println("this is default method ");
	}
}

//The default modifier is accessible only within package. 
public class DefaultInfo {

	public static void main(String[] args) {

		DefaultDemo obj = new DefaultDemo();// Compile Time Error
		obj.message();
		// here we can access default method of default class in same package

	}

}
