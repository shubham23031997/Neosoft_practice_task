package accessmodifiers;

public class AccessModifierTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DefaultDemo obj = new DefaultDemo();// Compile Time Error
		obj.message();
	}

}
