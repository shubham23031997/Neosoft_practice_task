package mapVsFlatmap;

import java.util.List;
import java.util.stream.Collectors;

public class MapVSFlatMap {

	public static void main(String[] args) {
		List<Customer> customers = CustomerDB.getAll();
		System.out.println(customers);

		List<String> emails = customers.stream().map(customer -> customer.getEmail()).collect(Collectors.toList());
		System.out.println(emails);

		List<List<String>> phoneNumbers = customers.stream().map(customer -> customer.getPhoneNumber())
				.collect(Collectors.toList());
		System.out.println(phoneNumbers);

		List<String> phoneNumbers1 =customers.stream().flatMap(customer -> customer.getPhoneNumber().stream())
				.collect(Collectors.toList());
		System.out.println(phoneNumbers1);
	}

}
