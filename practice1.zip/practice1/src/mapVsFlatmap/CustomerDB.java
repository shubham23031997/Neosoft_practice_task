package mapVsFlatmap;

import java.util.List;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CustomerDB {
	public static List<Customer> getAll() {
		return Stream
				.of(new Customer(101, "shubham", "malishubham@gmail.com", Arrays.asList("999999", "888888")),
						new Customer(104, "ram", "ram@gmail.com", Arrays.asList("777777", "666666")),
						new Customer(107, "shyam", "shyam@gmail.com", Arrays.asList("555555", "333333")))
				.collect(Collectors.toList());
	}
}
