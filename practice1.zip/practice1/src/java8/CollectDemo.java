package java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class CollectDemo {

	public static void main(String[] args) {
		// here removing duplicate and using set and making square of set

		List<Integer> ll = new ArrayList<>(Arrays.asList(10, 20, 25, 35, 55, 30, 20, 10));
		Set<Integer> square = ll.stream().map(m -> m * m).collect(Collectors.toSet());
		System.out.println(square);

		// applying filter on list and collecting string with applying filter startsWith
		List<String> ss = new ArrayList<>(Arrays.asList("shubham", "kaustubh", "ganesh", "bankar"));
		List<String> sss = ss.stream().filter(s -> s.startsWith("g")).collect(Collectors.toList());
		System.out.println(sss);

		// applying sorting on list
		List<String> ss1 = Arrays.asList("reflection", "deflection", "assertion");
		List<String> s = (List<String>) ss1.stream().sorted().collect(Collectors.toList());
		System.out.println(s);

		Integer s1 = ll.stream().filter(m -> m % 2 == 0).reduce(100, (ans, i) -> ans + i);
		System.out.println(s1);

		// converting integers into string
		List<String> l1 = ll.stream().map(m -> m.toString()).filter(x -> x.startsWith("3"))
				.collect(Collectors.toList());

		// map(m -> m+"") we can use this to convert into string
		System.out.println(l1);

		// printing only duplicate integers
		List<Integer> myList = new ArrayList<>(Arrays.asList(10, 20, 30, 40, 40, 50, 30));
		Set<Integer> set = new HashSet<>();
		myList.stream().filter(n -> !set.add(n)).forEach(System.out::println);

		// find first integer
		ll.stream().findFirst().ifPresent((m) -> System.out.println(m));
		// we can write with method reference....(System.out::println)

		// to count the total number of element present in list
		long count = ll.stream().count();
		System.out.println(count);

		// to get max element from list
		long max = ll.stream().max(Integer::compare).get();
		System.out.println(max);

		// to get min element form list
		long min = ll.stream().min(Integer::compare).get();
		System.out.println(min);

		// to print sorted list by default ascending order
		List<Integer> sortedlist = ll.stream().sorted().collect(Collectors.toList());
		System.out.println(sortedlist);

		// to print sorted list descending order
		List<Integer> sortedDecending = ll.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
		System.out.println(sortedDecending);

		List<String> stringList = new ArrayList<>(Arrays.asList("shubham", "karan", "sunil", "anil", "tina"));
		System.out.println(stringList);
		long count1 = stringList.stream().sorted().count();
		System.out.println(count1);

	}
}