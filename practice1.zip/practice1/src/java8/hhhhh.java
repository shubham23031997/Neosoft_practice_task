package java8;

public class hhhhh {

	public static void main(String[] args) {
		String str = "ganesh123pacharne";
		// String[] arrOfStr = str.split("123");
		String[] arr = str.split("");
		for (String character : arr)
			System.out.print(character);
//		for (String a : arrOfStr)
//			System.out.println(a);
//
//		System.out.println(arrOfStr[0]);
//		System.out.println(arrOfStr[1]);
	}
}