public class Fibonacci {
    public static void main(String args[]) {
        int i = 1, j = 1, k = 0;
        System.out.println(i);
        System.out.println(j);
        for(int n=0;n<10;n++){
            k=i+j;
            i=j;
            j=k;
            System.out.println(k);
        }

    }
}
//        public static int fibonacci ( int number){
//            if (number == 1 || number == 2) {
//                return 1;
//            }
//
//            int fibo1 = 1, fibo2 = 1, fibonacci = 1;
//            for (int i = 3; i <= number; i++) {
//                fibonacci = fibo1 + fibo2;
//                fibo1 = fibo2;
//                fibo2 = fibonacci;
//            }
//            return fibonacci;
//        }
//    }

