import java.io.*;
import java.util.Scanner;

public class ReverseString {
//	public static String StringReverse(String str1) {
//	
//		StringBuffer sb=new StringBuffer(str1);
//		sb.reverse();
//		return sb.toString();	
//		
//		//System.out.println( ReverseString.StringReverse("my name is shubham"));//put this is in  main
//	}
    public static void main(String args[]) {
        System.out.print("enter the string :");
        Scanner sc = new Scanner(System.in);
        String str = sc.next();
        String nstr = "";
        char ch;

        for (int i = str.length()-1; i >=0 ; i--) {// here >= is important
            ch = str.charAt(i); //extracts each character
            nstr =  nstr+ch ; //adds each character in front of the existing string..here nstr+ch and below ch+str
        }

//        for (int i = 0; i < str.length(); i++) {
//            ch = str.charAt(i); //extracts each character
//            nstr = ch + nstr; //adds each character in front of the existing string
//        }
        System.out.println("Reversed String: " + nstr);
    }
}

