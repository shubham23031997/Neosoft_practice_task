import java.util.Scanner;

public class PalindromeNumber {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number");
        int number = sc.nextInt();
        int temp, sum = 0, rem;
        temp = number;
        while (number > 0) {
            rem = number % 10;
            sum = sum * 10 + rem;
            number = number / 10;

        }
        if (sum == temp) {
            System.out.println("its pallindrome number");

        } else
            System.out.println("its not pallindrome number");

    }
}
