package interfaceabstract;

//(0 to 100%)abstraction
// abstract class must declared with abstract keyword
abstract class Car {
	int wheel;

	Car(int a) { // we can create constructor in abstract class
		this.wheel = a;
		System.out.println("I want to buy a Car");
	}

	abstract void run();// at least one method recommended to be abstract method but not necessary

	void changeGear() {
		System.out.println("gear changed");
	}

	final void cash() {
		System.out.println("need cash for buying car");
	}
}

// Creating a Child class which inherits Abstract class
class Porsche extends Car {
	Porsche(int a) {
		super(a);// we call constructor of abstract class by super method
	}

	void run() {
		// must provide implementation of abstract method
		System.out.println("car running safely!!");
	}

}
// Creating a AbstractTest class which calls abstract and non-abstract methods

public class AbstractTest {

	public static void main(String[] args) {
		// Car obj1=new Car(); //here we can not make object of abstract class
		Car obj = new Porsche(4);
		obj.run();
		obj.changeGear();
		obj.cash();
	}

}
