package interfaceabstract;

//Constructors we use for initializing objects, when we called new() key then constructors will be called
//100% abstraction..no constructor bcz we invoked constructors by object and interface not have object
interface Drowing {

	int a = 10; // Fields are public static final by default

	void drow(); // methods are public and abstract by default.

	void structure();// java 9 - private method

	default void stuctureImplemention() {
		structure();
	}
	// we can use private method only inside same interface (in default methods)
}

interface Sketching {
	void sketch(); // empty body

	default void pencile() {
		System.out.println("default method of interface");
	};// java 8

	static void visibility() {
		System.out.println("static method of interface");
	};
	// not compulsory to provide implementation of static & default method

}

public class InterfaceTest implements Drowing, Sketching {
	// we achieve multiple inheritance here
	@Override
	public void sketch() {

		System.out.println("I am sketching picture");
	}

	@Override
	public void drow() {

		System.out.println("I am drowing picture");
	}

	static void visibility() {
		System.out.println("static method of class");
	};

	public static void main(String[] args) {
		InterfaceTest it = new InterfaceTest();
		it.sketch();
		it.drow();
		it.pencile();
		it.stuctureImplemention();
		Sketching.visibility();
		// here we calling static method with reference of interface
		// it does not takes space in memory
		InterfaceTest.visibility();
		// here we calling static method with reference of class.
		System.out.println(Drowing.a);
		// we calling with reference & its public so that we can call
		// Drowing.a=20; //we can not change value because its final

	}

	@Override
	public void structure() {
		// TODO Auto-generated method stub

	}

}

//String s=new String("aadi");
