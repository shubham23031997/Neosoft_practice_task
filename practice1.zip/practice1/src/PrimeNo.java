import java.util.Scanner;

class PrimeNo {
    public static void main(String args[]) {
        int i, m, flag = 0;
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        m = number / 2;
        if (number == 0 || number == 1) {
            System.out.println(number + " not prime number");
        } else {
            for (i = 2; i < m; i++) {
                if (number % i == 0) {
                    System.out.println(number + " not prime number");
                    flag = 1;
                    break;
                }
                if (flag == 0) {
                    System.out.println(number + " is prime number");
                    break;
                }
//                else {System.out.println(number + " is prime number");
//                break;}
            }
        }
    }
}
//import java.util.Scanner;
//
//public class PrimeNo{
//    public static void main(String args[]){
//        int i,m=0,flag=0;
//        Scanner sc=new Scanner(System.in);
//        int n=sc.nextInt();
//        m=n/2;
//        if(n==0||n==1)
//        {
//            System.out.println(n+" is not prime number");
//        }
//        else
//        {
//            for(i=2;i<=m;i++){
//                if(n%i==0)
//                {
//                    System.out.println(n+" is not prime number");
//                    flag=1;
//                    break;
//                }
//            }
//            if(flag==0)  {
//                System.out.println(n+" is prime number");
//            }
//        }
//    }
//}