package ClientInterview;

public class CharCount {

	public static void main(String[] args) {
		String str = "my name is shubham";
		int i;
//		int count = 0;
//		for (int i = 0; i < sss.length(); i++) {
//			if (sss.charAt(i) != ' ')
//				count++;
//
//		}
//		System.out.println(count);System.out.println("Total number of characters in a string: " + count);
		int counter[] = new int[256];

		for (i = 0; i < str.length(); i++) {
			counter[(int) str.charAt(i)]++;
		}
		for (i = 0; i < 256; i++) {
			if (counter[i] != 0) {
				// prints frequency of characters
				System.out.println((char) i + " --> " + counter[i]);
			}
		}
	}
}
