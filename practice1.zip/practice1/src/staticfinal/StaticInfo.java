package staticfinal;

// static keyword used for memory management mainly. We apply static keyword with 
// variables, methods, blocks and nested classes

class Resource {
	int id;
	String name;
	static String companyName = "NeoSoft";// here we use static for variable
	static int count = 0;// it takes memory once

	Resource(int id, String name) {
		// Resource(int id, String name, String companyName) {
		this.id = id;
		this.name = name;
		// this.companyName = companyName;
		count++;
		System.out.println("count of resource is=" + count);

	}

	void display() {
		System.out.println(id + " " + name + " " + companyName);
	}

	static void changeCompany() {
		companyName = "ProductBased";
	}

	private static int data;

	static class InnerClass { // nested class/inner class
		static void msg() {
			System.out.println("data is " + data);
		}
		// A static nested class directly access static members of outer class including
		// private static members
	}

	// A static method can only use and call other static methods or static data
	// members.
	// static block is used to initialized static data members
	static {
		data = 30;
		// static block can loaded before main class
		// static block run only once when a class is loaded into memory
		System.out.println("static block is printed ...invoked");
	}
}

public class StaticInfo {

	public static void main(String[] args) {
		Resource.changeCompany();
		// A static method belongs to the class rather than the object of a class.
		Resource r1 = new Resource(1, "shubham");
		Resource r2 = new Resource(2, "kaustubh");
		Resource r3 = new Resource(3, "Ganesh");
		r1.display();
		r2.display();
		r3.display();
		r1.changeCompany();
		// we can call through object also

		Resource.InnerClass.msg();
		// no need to create the instance of static nested class
	}
}
