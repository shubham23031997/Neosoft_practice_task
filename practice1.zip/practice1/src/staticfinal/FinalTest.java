package staticfinal;
//(finally always  executed after try catch except System.exit())

class FinalDemo { // final keyword is used to variables, methods and classes
	final int a = 10;
//	a=a/2;

	final int subtraction(int x, int y) {
		int z = x - y;
		System.out.println("Subtraction of y from x  is z=" + z);
		return z;
	}
}

final class Finalclass {
	// can not extends final class
}

public class FinalTest extends FinalDemo {

	public static void main(String[] args) {
// @Override
// final int subtraction(int x, int y) {
//			int z =  y-x;
//			System.out.println("Subtraction of x from y is z=" + z);
//			return z;
//		}
// we can not override final method

		FinalTest ft = new FinalTest();
		ft.subtraction(20, 10);
	}
}