package jdbc;

//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.Statement;
//
public class Create_db {
//
	public static void main(String[] args) throws Exception {
//		try {
//			String driverClassName = "sun.jdbc.odbc.jdbcOdbcDriver";
//			String url = "jdbc:mysql://localhost:3306/";
//			String dataBaseName = "db1";
//			String username = "root";
//			String password = "root";
//			Class.forName(driverClassName);
//			Connection connection = DriverManager.getConnection(url, username, password);
//			String sql = "CREATE DATABASE" + dataBaseName;
//
//			Statement statement = connection.createStatement();
//			statement.executeUpdate(sql);
//			statement.close();
//			// JOptionPane.showMessageDialog(parentComponent);
//
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	}
//
}
